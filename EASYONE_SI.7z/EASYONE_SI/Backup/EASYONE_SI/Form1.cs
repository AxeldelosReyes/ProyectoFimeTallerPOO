﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EASYONE_SI
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void idiomaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nom_usuario, contra, tipo_usuario, admin_def="Adminstrador", contra_def="1";
            nom_usuario = Convert.ToString(txt_usuario.Text);
            tipo_usuario = Convert.ToString(cmbox_tipo_usuario.Text);
            contra = Convert.ToString(txt_contra.Text);
            if (tipo_usuario != "Administrador")
            {

                if (nom_usuario != admin_def)
                {
                    MessageBox.Show("ERROR");

                }
                else if (contra != contra_def)
                {
                    MessageBox.Show("ERROR");

                }
                else if (nom_usuario != admin_def && contra != contra_def)
                {
                    MessageBox.Show("ERROR");
                }
            }
            else
            {
                MDI abrir = new MDI();
                this.Hide();
                abrir.Show();
                
            }

        }

        private void cerrarToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
