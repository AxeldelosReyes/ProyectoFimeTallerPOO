﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EASYONE_SI
{
    public partial class Inicio : Form
    {
        public Inicio()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string administrador, contra;
            administrador=Convert.ToString(n_admin.Text);
            contra=Convert.ToString(n_contra);
            if (n_admin.Text != "" && n_contra.Text != "")
            {
                
                Login abrir = new Login(1);
                this.Hide();
                abrir.Show();
            }
            else
            {
                MessageBox.Show("Llena los campos antes de continuar");
            }

            
        }
    }
}
