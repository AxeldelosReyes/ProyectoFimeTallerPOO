﻿namespace EASYONE_SI
{
    partial class Libro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label id_LibroLabel;
            System.Windows.Forms.Label nombre_LibroLabel;
            System.Windows.Forms.Label cantidadLabel;
            System.Windows.Forms.Label existenciaLabel;
            System.Windows.Forms.Label tipo_LibroLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Libro));
            this.dERDataSet = new EASYONE_SI.DERDataSet();
            this.lIBROBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lIBROTableAdapter = new EASYONE_SI.DERDataSetTableAdapters.LIBROTableAdapter();
            this.tableAdapterManager = new EASYONE_SI.DERDataSetTableAdapters.TableAdapterManager();
            this.lIBROBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.lIBROBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.lIBRODataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.id_LibroTextBox = new System.Windows.Forms.TextBox();
            this.nombre_LibroTextBox = new System.Windows.Forms.TextBox();
            this.cantidadTextBox = new System.Windows.Forms.TextBox();
            this.existenciaCheckBox = new System.Windows.Forms.CheckBox();
            this.tipo_LibroComboBox = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            id_LibroLabel = new System.Windows.Forms.Label();
            nombre_LibroLabel = new System.Windows.Forms.Label();
            cantidadLabel = new System.Windows.Forms.Label();
            existenciaLabel = new System.Windows.Forms.Label();
            tipo_LibroLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dERDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lIBROBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lIBROBindingNavigator)).BeginInit();
            this.lIBROBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lIBRODataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // id_LibroLabel
            // 
            id_LibroLabel.AutoSize = true;
            id_LibroLabel.Location = new System.Drawing.Point(151, 283);
            id_LibroLabel.Name = "id_LibroLabel";
            id_LibroLabel.Size = new System.Drawing.Size(45, 13);
            id_LibroLabel.TabIndex = 2;
            id_LibroLabel.Text = "Id Libro:";
            // 
            // nombre_LibroLabel
            // 
            nombre_LibroLabel.AutoSize = true;
            nombre_LibroLabel.Location = new System.Drawing.Point(123, 315);
            nombre_LibroLabel.Name = "nombre_LibroLabel";
            nombre_LibroLabel.Size = new System.Drawing.Size(73, 13);
            nombre_LibroLabel.TabIndex = 4;
            nombre_LibroLabel.Text = "Nombre Libro:";
            // 
            // cantidadLabel
            // 
            cantidadLabel.AutoSize = true;
            cantidadLabel.Location = new System.Drawing.Point(144, 355);
            cantidadLabel.Name = "cantidadLabel";
            cantidadLabel.Size = new System.Drawing.Size(52, 13);
            cantidadLabel.TabIndex = 6;
            cantidadLabel.Text = "Cantidad:";
            // 
            // existenciaLabel
            // 
            existenciaLabel.AutoSize = true;
            existenciaLabel.Location = new System.Drawing.Point(144, 395);
            existenciaLabel.Name = "existenciaLabel";
            existenciaLabel.Size = new System.Drawing.Size(58, 13);
            existenciaLabel.TabIndex = 8;
            existenciaLabel.Text = "Existencia:";
            // 
            // tipo_LibroLabel
            // 
            tipo_LibroLabel.AutoSize = true;
            tipo_LibroLabel.Location = new System.Drawing.Point(139, 437);
            tipo_LibroLabel.Name = "tipo_LibroLabel";
            tipo_LibroLabel.Size = new System.Drawing.Size(57, 13);
            tipo_LibroLabel.TabIndex = 10;
            tipo_LibroLabel.Text = "Tipo Libro:";
            // 
            // dERDataSet
            // 
            this.dERDataSet.DataSetName = "DERDataSet";
            this.dERDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lIBROBindingSource
            // 
            this.lIBROBindingSource.DataMember = "LIBRO";
            this.lIBROBindingSource.DataSource = this.dERDataSet;
            // 
            // lIBROTableAdapter
            // 
            this.lIBROTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.LIBROTableAdapter = this.lIBROTableAdapter;
            this.tableAdapterManager.PRÉSTAMOTableAdapter = null;
            this.tableAdapterManager.TIPO_lIBROTableAdapter = null;
            this.tableAdapterManager.TIPO_USUARIOTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = EASYONE_SI.DERDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.USUARIOTableAdapter = null;
            // 
            // lIBROBindingNavigator
            // 
            this.lIBROBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.lIBROBindingNavigator.BindingSource = this.lIBROBindingSource;
            this.lIBROBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.lIBROBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.lIBROBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.lIBROBindingNavigatorSaveItem});
            this.lIBROBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.lIBROBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.lIBROBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.lIBROBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.lIBROBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.lIBROBindingNavigator.Name = "lIBROBindingNavigator";
            this.lIBROBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.lIBROBindingNavigator.Size = new System.Drawing.Size(574, 25);
            this.lIBROBindingNavigator.TabIndex = 0;
            this.lIBROBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Agregar nuevo";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 22);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Número total de elementos";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Eliminar";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Mover primero";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Mover anterior";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Posición";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Posición actual";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Mover siguiente";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Mover último";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // lIBROBindingNavigatorSaveItem
            // 
            this.lIBROBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.lIBROBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("lIBROBindingNavigatorSaveItem.Image")));
            this.lIBROBindingNavigatorSaveItem.Name = "lIBROBindingNavigatorSaveItem";
            this.lIBROBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.lIBROBindingNavigatorSaveItem.Text = "Guardar datos";
            this.lIBROBindingNavigatorSaveItem.Click += new System.EventHandler(this.lIBROBindingNavigatorSaveItem_Click);
            // 
            // lIBRODataGridView
            // 
            this.lIBRODataGridView.AutoGenerateColumns = false;
            this.lIBRODataGridView.BackgroundColor = System.Drawing.Color.RosyBrown;
            this.lIBRODataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.lIBRODataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewCheckBoxColumn1,
            this.dataGridViewTextBoxColumn4});
            this.lIBRODataGridView.DataSource = this.lIBROBindingSource;
            this.lIBRODataGridView.Location = new System.Drawing.Point(15, 50);
            this.lIBRODataGridView.Name = "lIBRODataGridView";
            this.lIBRODataGridView.Size = new System.Drawing.Size(525, 207);
            this.lIBRODataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Id_Libro";
            this.dataGridViewTextBoxColumn1.HeaderText = "Id_Libro";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Nombre_Libro";
            this.dataGridViewTextBoxColumn2.HeaderText = "Nombre_Libro";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Cantidad";
            this.dataGridViewTextBoxColumn3.HeaderText = "Cantidad";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewCheckBoxColumn1
            // 
            this.dataGridViewCheckBoxColumn1.DataPropertyName = "Existencia";
            this.dataGridViewCheckBoxColumn1.HeaderText = "Existencia";
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Tipo_Libro";
            this.dataGridViewTextBoxColumn4.HeaderText = "Tipo_Libro";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // id_LibroTextBox
            // 
            this.id_LibroTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.lIBROBindingSource, "Id_Libro", true));
            this.id_LibroTextBox.Location = new System.Drawing.Point(202, 280);
            this.id_LibroTextBox.Name = "id_LibroTextBox";
            this.id_LibroTextBox.Size = new System.Drawing.Size(100, 20);
            this.id_LibroTextBox.TabIndex = 3;
            // 
            // nombre_LibroTextBox
            // 
            this.nombre_LibroTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.lIBROBindingSource, "Nombre_Libro", true));
            this.nombre_LibroTextBox.Location = new System.Drawing.Point(202, 315);
            this.nombre_LibroTextBox.Name = "nombre_LibroTextBox";
            this.nombre_LibroTextBox.Size = new System.Drawing.Size(100, 20);
            this.nombre_LibroTextBox.TabIndex = 5;
            // 
            // cantidadTextBox
            // 
            this.cantidadTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.lIBROBindingSource, "Cantidad", true));
            this.cantidadTextBox.Location = new System.Drawing.Point(202, 355);
            this.cantidadTextBox.Name = "cantidadTextBox";
            this.cantidadTextBox.Size = new System.Drawing.Size(100, 20);
            this.cantidadTextBox.TabIndex = 7;
            // 
            // existenciaCheckBox
            // 
            this.existenciaCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.lIBROBindingSource, "Existencia", true));
            this.existenciaCheckBox.Location = new System.Drawing.Point(208, 390);
            this.existenciaCheckBox.Name = "existenciaCheckBox";
            this.existenciaCheckBox.Size = new System.Drawing.Size(104, 24);
            this.existenciaCheckBox.TabIndex = 9;
            this.existenciaCheckBox.Text = "SI";
            this.existenciaCheckBox.UseVisualStyleBackColor = true;
            // 
            // tipo_LibroComboBox
            // 
            this.tipo_LibroComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.lIBROBindingSource, "Tipo_Libro", true));
            this.tipo_LibroComboBox.FormattingEnabled = true;
            this.tipo_LibroComboBox.Location = new System.Drawing.Point(202, 434);
            this.tipo_LibroComboBox.Name = "tipo_LibroComboBox";
            this.tipo_LibroComboBox.Size = new System.Drawing.Size(121, 21);
            this.tipo_LibroComboBox.TabIndex = 11;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(355, 334);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 41);
            this.button1.TabIndex = 12;
            this.button1.Text = "Agregar";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // Libro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(574, 476);
            this.Controls.Add(this.button1);
            this.Controls.Add(tipo_LibroLabel);
            this.Controls.Add(this.tipo_LibroComboBox);
            this.Controls.Add(existenciaLabel);
            this.Controls.Add(this.existenciaCheckBox);
            this.Controls.Add(cantidadLabel);
            this.Controls.Add(this.cantidadTextBox);
            this.Controls.Add(nombre_LibroLabel);
            this.Controls.Add(this.nombre_LibroTextBox);
            this.Controls.Add(id_LibroLabel);
            this.Controls.Add(this.id_LibroTextBox);
            this.Controls.Add(this.lIBRODataGridView);
            this.Controls.Add(this.lIBROBindingNavigator);
            this.Name = "Libro";
            this.Text = "Libro";
            this.Load += new System.EventHandler(this.Libro_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dERDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lIBROBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lIBROBindingNavigator)).EndInit();
            this.lIBROBindingNavigator.ResumeLayout(false);
            this.lIBROBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lIBRODataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DERDataSet dERDataSet;
        private System.Windows.Forms.BindingSource lIBROBindingSource;
        private EASYONE_SI.DERDataSetTableAdapters.LIBROTableAdapter lIBROTableAdapter;
        private EASYONE_SI.DERDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator lIBROBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton lIBROBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView lIBRODataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.TextBox id_LibroTextBox;
        private System.Windows.Forms.TextBox nombre_LibroTextBox;
        private System.Windows.Forms.TextBox cantidadTextBox;
        private System.Windows.Forms.CheckBox existenciaCheckBox;
        private System.Windows.Forms.ComboBox tipo_LibroComboBox;
        private System.Windows.Forms.Button button1;
    }
}