﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EASYONE_SI
{
    public partial class Libro : Form
    {
        public Libro()
        {
            InitializeComponent();
        }

        private void lIBROBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.lIBROBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dERDataSet);

        }

        private void Libro_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'dERDataSet.LIBRO' Puede moverla o quitarla según sea necesario.
            this.lIBROTableAdapter.Fill(this.dERDataSet.LIBRO);

        }
    }
}
