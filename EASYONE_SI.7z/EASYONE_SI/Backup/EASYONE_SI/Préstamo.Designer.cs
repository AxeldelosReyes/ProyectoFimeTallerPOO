﻿namespace EASYONE_SI
{
    partial class Préstamo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label id_PrestamoLabel;
            System.Windows.Forms.Label fecha_PrestamoLabel;
            System.Windows.Forms.Label fecha_DevoluciónLabel;
            System.Windows.Forms.Label id_LibroLabel;
            System.Windows.Forms.Label id_UsuarioLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Préstamo));
            this.dERDataSet = new EASYONE_SI.DERDataSet();
            this.pRÉSTAMOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pRÉSTAMOTableAdapter = new EASYONE_SI.DERDataSetTableAdapters.PRÉSTAMOTableAdapter();
            this.tableAdapterManager = new EASYONE_SI.DERDataSetTableAdapters.TableAdapterManager();
            this.pRÉSTAMOBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.pRÉSTAMOBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.pRÉSTAMODataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.id_PrestamoTextBox = new System.Windows.Forms.TextBox();
            this.fecha_PrestamoDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.fecha_DevoluciónDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.id_LibroTextBox = new System.Windows.Forms.TextBox();
            this.id_UsuarioTextBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            id_PrestamoLabel = new System.Windows.Forms.Label();
            fecha_PrestamoLabel = new System.Windows.Forms.Label();
            fecha_DevoluciónLabel = new System.Windows.Forms.Label();
            id_LibroLabel = new System.Windows.Forms.Label();
            id_UsuarioLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dERDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRÉSTAMOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRÉSTAMOBindingNavigator)).BeginInit();
            this.pRÉSTAMOBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pRÉSTAMODataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // id_PrestamoLabel
            // 
            id_PrestamoLabel.AutoSize = true;
            id_PrestamoLabel.Location = new System.Drawing.Point(48, 191);
            id_PrestamoLabel.Name = "id_PrestamoLabel";
            id_PrestamoLabel.Size = new System.Drawing.Size(66, 13);
            id_PrestamoLabel.TabIndex = 2;
            id_PrestamoLabel.Text = "Id Prestamo:";
            // 
            // fecha_PrestamoLabel
            // 
            fecha_PrestamoLabel.AutoSize = true;
            fecha_PrestamoLabel.Location = new System.Drawing.Point(35, 234);
            fecha_PrestamoLabel.Name = "fecha_PrestamoLabel";
            fecha_PrestamoLabel.Size = new System.Drawing.Size(87, 13);
            fecha_PrestamoLabel.TabIndex = 4;
            fecha_PrestamoLabel.Text = "Fecha Prestamo:";
            // 
            // fecha_DevoluciónLabel
            // 
            fecha_DevoluciónLabel.AutoSize = true;
            fecha_DevoluciónLabel.Location = new System.Drawing.Point(25, 278);
            fecha_DevoluciónLabel.Name = "fecha_DevoluciónLabel";
            fecha_DevoluciónLabel.Size = new System.Drawing.Size(97, 13);
            fecha_DevoluciónLabel.TabIndex = 6;
            fecha_DevoluciónLabel.Text = "Fecha Devolución:";
            // 
            // id_LibroLabel
            // 
            id_LibroLabel.AutoSize = true;
            id_LibroLabel.Location = new System.Drawing.Point(69, 308);
            id_LibroLabel.Name = "id_LibroLabel";
            id_LibroLabel.Size = new System.Drawing.Size(45, 13);
            id_LibroLabel.TabIndex = 8;
            id_LibroLabel.Text = "Id Libro:";
            // 
            // id_UsuarioLabel
            // 
            id_UsuarioLabel.AutoSize = true;
            id_UsuarioLabel.Location = new System.Drawing.Point(65, 354);
            id_UsuarioLabel.Name = "id_UsuarioLabel";
            id_UsuarioLabel.Size = new System.Drawing.Size(57, 13);
            id_UsuarioLabel.TabIndex = 10;
            id_UsuarioLabel.Text = "id Usuario:";
            // 
            // dERDataSet
            // 
            this.dERDataSet.DataSetName = "DERDataSet";
            this.dERDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pRÉSTAMOBindingSource
            // 
            this.pRÉSTAMOBindingSource.DataMember = "PRÉSTAMO";
            this.pRÉSTAMOBindingSource.DataSource = this.dERDataSet;
            // 
            // pRÉSTAMOTableAdapter
            // 
            this.pRÉSTAMOTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.LIBROTableAdapter = null;
            this.tableAdapterManager.PRÉSTAMOTableAdapter = this.pRÉSTAMOTableAdapter;
            this.tableAdapterManager.TIPO_lIBROTableAdapter = null;
            this.tableAdapterManager.TIPO_USUARIOTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = EASYONE_SI.DERDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.USUARIOTableAdapter = null;
            // 
            // pRÉSTAMOBindingNavigator
            // 
            this.pRÉSTAMOBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.pRÉSTAMOBindingNavigator.BindingSource = this.pRÉSTAMOBindingSource;
            this.pRÉSTAMOBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.pRÉSTAMOBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.pRÉSTAMOBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.pRÉSTAMOBindingNavigatorSaveItem});
            this.pRÉSTAMOBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.pRÉSTAMOBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.pRÉSTAMOBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.pRÉSTAMOBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.pRÉSTAMOBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.pRÉSTAMOBindingNavigator.Name = "pRÉSTAMOBindingNavigator";
            this.pRÉSTAMOBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.pRÉSTAMOBindingNavigator.Size = new System.Drawing.Size(632, 25);
            this.pRÉSTAMOBindingNavigator.TabIndex = 0;
            this.pRÉSTAMOBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Agregar nuevo";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 22);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Número total de elementos";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Eliminar";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Mover primero";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Mover anterior";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Posición";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Posición actual";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Mover siguiente";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Mover último";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // pRÉSTAMOBindingNavigatorSaveItem
            // 
            this.pRÉSTAMOBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.pRÉSTAMOBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("pRÉSTAMOBindingNavigatorSaveItem.Image")));
            this.pRÉSTAMOBindingNavigatorSaveItem.Name = "pRÉSTAMOBindingNavigatorSaveItem";
            this.pRÉSTAMOBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.pRÉSTAMOBindingNavigatorSaveItem.Text = "Guardar datos";
            this.pRÉSTAMOBindingNavigatorSaveItem.Click += new System.EventHandler(this.pRÉSTAMOBindingNavigatorSaveItem_Click);
            // 
            // pRÉSTAMODataGridView
            // 
            this.pRÉSTAMODataGridView.AutoGenerateColumns = false;
            this.pRÉSTAMODataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.pRÉSTAMODataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.pRÉSTAMODataGridView.DataSource = this.pRÉSTAMOBindingSource;
            this.pRÉSTAMODataGridView.Location = new System.Drawing.Point(38, 47);
            this.pRÉSTAMODataGridView.Name = "pRÉSTAMODataGridView";
            this.pRÉSTAMODataGridView.Size = new System.Drawing.Size(538, 114);
            this.pRÉSTAMODataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Id_Prestamo";
            this.dataGridViewTextBoxColumn1.HeaderText = "Id_Prestamo";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Fecha_Prestamo";
            this.dataGridViewTextBoxColumn2.HeaderText = "Fecha_Prestamo";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Fecha_Devolución";
            this.dataGridViewTextBoxColumn3.HeaderText = "Fecha_Devolución";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Id_Libro";
            this.dataGridViewTextBoxColumn4.HeaderText = "Id_Libro";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "id_Usuario";
            this.dataGridViewTextBoxColumn5.HeaderText = "id_Usuario";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // id_PrestamoTextBox
            // 
            this.id_PrestamoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.pRÉSTAMOBindingSource, "Id_Prestamo", true));
            this.id_PrestamoTextBox.Location = new System.Drawing.Point(128, 188);
            this.id_PrestamoTextBox.Name = "id_PrestamoTextBox";
            this.id_PrestamoTextBox.Size = new System.Drawing.Size(100, 20);
            this.id_PrestamoTextBox.TabIndex = 3;
            // 
            // fecha_PrestamoDateTimePicker
            // 
            this.fecha_PrestamoDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.pRÉSTAMOBindingSource, "Fecha_Prestamo", true));
            this.fecha_PrestamoDateTimePicker.Location = new System.Drawing.Point(128, 228);
            this.fecha_PrestamoDateTimePicker.Name = "fecha_PrestamoDateTimePicker";
            this.fecha_PrestamoDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.fecha_PrestamoDateTimePicker.TabIndex = 5;
            // 
            // fecha_DevoluciónDateTimePicker
            // 
            this.fecha_DevoluciónDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.pRÉSTAMOBindingSource, "Fecha_Devolución", true));
            this.fecha_DevoluciónDateTimePicker.Location = new System.Drawing.Point(128, 272);
            this.fecha_DevoluciónDateTimePicker.Name = "fecha_DevoluciónDateTimePicker";
            this.fecha_DevoluciónDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.fecha_DevoluciónDateTimePicker.TabIndex = 7;
            // 
            // id_LibroTextBox
            // 
            this.id_LibroTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.pRÉSTAMOBindingSource, "Id_Libro", true));
            this.id_LibroTextBox.Location = new System.Drawing.Point(128, 305);
            this.id_LibroTextBox.Name = "id_LibroTextBox";
            this.id_LibroTextBox.Size = new System.Drawing.Size(100, 20);
            this.id_LibroTextBox.TabIndex = 9;
            // 
            // id_UsuarioTextBox
            // 
            this.id_UsuarioTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.pRÉSTAMOBindingSource, "id_Usuario", true));
            this.id_UsuarioTextBox.Location = new System.Drawing.Point(128, 351);
            this.id_UsuarioTextBox.Name = "id_UsuarioTextBox";
            this.id_UsuarioTextBox.Size = new System.Drawing.Size(100, 20);
            this.id_UsuarioTextBox.TabIndex = 11;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(259, 339);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(113, 43);
            this.button1.TabIndex = 12;
            this.button1.Text = "Generar nuevo préstamo";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // Préstamo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.IndianRed;
            this.ClientSize = new System.Drawing.Size(632, 434);
            this.Controls.Add(this.button1);
            this.Controls.Add(id_UsuarioLabel);
            this.Controls.Add(this.id_UsuarioTextBox);
            this.Controls.Add(id_LibroLabel);
            this.Controls.Add(this.id_LibroTextBox);
            this.Controls.Add(fecha_DevoluciónLabel);
            this.Controls.Add(this.fecha_DevoluciónDateTimePicker);
            this.Controls.Add(fecha_PrestamoLabel);
            this.Controls.Add(this.fecha_PrestamoDateTimePicker);
            this.Controls.Add(id_PrestamoLabel);
            this.Controls.Add(this.id_PrestamoTextBox);
            this.Controls.Add(this.pRÉSTAMODataGridView);
            this.Controls.Add(this.pRÉSTAMOBindingNavigator);
            this.Name = "Préstamo";
            this.Text = "Préstamo";
            this.Load += new System.EventHandler(this.Préstamo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dERDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRÉSTAMOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRÉSTAMOBindingNavigator)).EndInit();
            this.pRÉSTAMOBindingNavigator.ResumeLayout(false);
            this.pRÉSTAMOBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pRÉSTAMODataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DERDataSet dERDataSet;
        private System.Windows.Forms.BindingSource pRÉSTAMOBindingSource;
        private EASYONE_SI.DERDataSetTableAdapters.PRÉSTAMOTableAdapter pRÉSTAMOTableAdapter;
        private EASYONE_SI.DERDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator pRÉSTAMOBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton pRÉSTAMOBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView pRÉSTAMODataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.TextBox id_PrestamoTextBox;
        private System.Windows.Forms.DateTimePicker fecha_PrestamoDateTimePicker;
        private System.Windows.Forms.DateTimePicker fecha_DevoluciónDateTimePicker;
        private System.Windows.Forms.TextBox id_LibroTextBox;
        private System.Windows.Forms.TextBox id_UsuarioTextBox;
        private System.Windows.Forms.Button button1;
    }
}