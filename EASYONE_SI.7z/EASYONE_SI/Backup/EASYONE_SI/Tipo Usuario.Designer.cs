﻿namespace EASYONE_SI
{
    partial class Tipo_Usuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tipo_Usuario));
            System.Windows.Forms.Label tipo_usuarioLabel;
            System.Windows.Forms.Label clasificaciónLabel;
            this.dERDataSet = new EASYONE_SI.DERDataSet();
            this.tIPO_USUARIOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tIPO_USUARIOTableAdapter = new EASYONE_SI.DERDataSetTableAdapters.TIPO_USUARIOTableAdapter();
            this.tableAdapterManager = new EASYONE_SI.DERDataSetTableAdapters.TableAdapterManager();
            this.tIPO_USUARIOBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.tIPO_USUARIOBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.tIPO_USUARIODataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tipo_usuarioTextBox = new System.Windows.Forms.TextBox();
            this.clasificaciónTextBox = new System.Windows.Forms.TextBox();
            this.Agregar = new System.Windows.Forms.Button();
            tipo_usuarioLabel = new System.Windows.Forms.Label();
            clasificaciónLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dERDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tIPO_USUARIOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tIPO_USUARIOBindingNavigator)).BeginInit();
            this.tIPO_USUARIOBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tIPO_USUARIODataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // dERDataSet
            // 
            this.dERDataSet.DataSetName = "DERDataSet";
            this.dERDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tIPO_USUARIOBindingSource
            // 
            this.tIPO_USUARIOBindingSource.DataMember = "TIPO_USUARIO";
            this.tIPO_USUARIOBindingSource.DataSource = this.dERDataSet;
            // 
            // tIPO_USUARIOTableAdapter
            // 
            this.tIPO_USUARIOTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.LIBROTableAdapter = null;
            this.tableAdapterManager.PRÉSTAMOTableAdapter = null;
            this.tableAdapterManager.TIPO_lIBROTableAdapter = null;
            this.tableAdapterManager.TIPO_USUARIOTableAdapter = this.tIPO_USUARIOTableAdapter;
            this.tableAdapterManager.UpdateOrder = EASYONE_SI.DERDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.USUARIOTableAdapter = null;
            // 
            // tIPO_USUARIOBindingNavigator
            // 
            this.tIPO_USUARIOBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.tIPO_USUARIOBindingNavigator.BindingSource = this.tIPO_USUARIOBindingSource;
            this.tIPO_USUARIOBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.tIPO_USUARIOBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.tIPO_USUARIOBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.tIPO_USUARIOBindingNavigatorSaveItem});
            this.tIPO_USUARIOBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.tIPO_USUARIOBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.tIPO_USUARIOBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.tIPO_USUARIOBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.tIPO_USUARIOBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.tIPO_USUARIOBindingNavigator.Name = "tIPO_USUARIOBindingNavigator";
            this.tIPO_USUARIOBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.tIPO_USUARIOBindingNavigator.Size = new System.Drawing.Size(355, 25);
            this.tIPO_USUARIOBindingNavigator.TabIndex = 0;
            this.tIPO_USUARIOBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Mover primero";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Mover anterior";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Posición";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Posición actual";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 22);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Número total de elementos";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Mover siguiente";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Mover último";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Agregar nuevo";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Eliminar";
            // 
            // tIPO_USUARIOBindingNavigatorSaveItem
            // 
            this.tIPO_USUARIOBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tIPO_USUARIOBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("tIPO_USUARIOBindingNavigatorSaveItem.Image")));
            this.tIPO_USUARIOBindingNavigatorSaveItem.Name = "tIPO_USUARIOBindingNavigatorSaveItem";
            this.tIPO_USUARIOBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.tIPO_USUARIOBindingNavigatorSaveItem.Text = "Guardar datos";
            this.tIPO_USUARIOBindingNavigatorSaveItem.Click += new System.EventHandler(this.tIPO_USUARIOBindingNavigatorSaveItem_Click);
            // 
            // tIPO_USUARIODataGridView
            // 
            this.tIPO_USUARIODataGridView.AutoGenerateColumns = false;
            this.tIPO_USUARIODataGridView.BackgroundColor = System.Drawing.Color.Teal;
            this.tIPO_USUARIODataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tIPO_USUARIODataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.tIPO_USUARIODataGridView.DataSource = this.tIPO_USUARIOBindingSource;
            this.tIPO_USUARIODataGridView.Location = new System.Drawing.Point(48, 198);
            this.tIPO_USUARIODataGridView.Name = "tIPO_USUARIODataGridView";
            this.tIPO_USUARIODataGridView.Size = new System.Drawing.Size(238, 104);
            this.tIPO_USUARIODataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Tipo_usuario";
            this.dataGridViewTextBoxColumn1.HeaderText = "Tipo_usuario";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Clasificación";
            this.dataGridViewTextBoxColumn2.HeaderText = "Clasificación";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // tipo_usuarioLabel
            // 
            tipo_usuarioLabel.AutoSize = true;
            tipo_usuarioLabel.Location = new System.Drawing.Point(24, 57);
            tipo_usuarioLabel.Name = "tipo_usuarioLabel";
            tipo_usuarioLabel.Size = new System.Drawing.Size(68, 13);
            tipo_usuarioLabel.TabIndex = 2;
            tipo_usuarioLabel.Text = "Tipo usuario:";
            // 
            // tipo_usuarioTextBox
            // 
            this.tipo_usuarioTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tIPO_USUARIOBindingSource, "Tipo_usuario", true));
            this.tipo_usuarioTextBox.Location = new System.Drawing.Point(108, 57);
            this.tipo_usuarioTextBox.Name = "tipo_usuarioTextBox";
            this.tipo_usuarioTextBox.Size = new System.Drawing.Size(100, 20);
            this.tipo_usuarioTextBox.TabIndex = 3;
            // 
            // clasificaciónLabel
            // 
            clasificaciónLabel.AutoSize = true;
            clasificaciónLabel.Location = new System.Drawing.Point(24, 124);
            clasificaciónLabel.Name = "clasificaciónLabel";
            clasificaciónLabel.Size = new System.Drawing.Size(69, 13);
            clasificaciónLabel.TabIndex = 4;
            clasificaciónLabel.Text = "Clasificación:";
            // 
            // clasificaciónTextBox
            // 
            this.clasificaciónTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tIPO_USUARIOBindingSource, "Clasificación", true));
            this.clasificaciónTextBox.Location = new System.Drawing.Point(108, 124);
            this.clasificaciónTextBox.Name = "clasificaciónTextBox";
            this.clasificaciónTextBox.Size = new System.Drawing.Size(100, 20);
            this.clasificaciónTextBox.TabIndex = 5;
            // 
            // Agregar
            // 
            this.Agregar.Location = new System.Drawing.Point(235, 114);
            this.Agregar.Name = "Agregar";
            this.Agregar.Size = new System.Drawing.Size(75, 23);
            this.Agregar.TabIndex = 6;
            this.Agregar.Text = "Agregar";
            this.Agregar.UseVisualStyleBackColor = true;
            // 
            // Tipo_Usuario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(355, 347);
            this.Controls.Add(this.Agregar);
            this.Controls.Add(clasificaciónLabel);
            this.Controls.Add(this.clasificaciónTextBox);
            this.Controls.Add(tipo_usuarioLabel);
            this.Controls.Add(this.tipo_usuarioTextBox);
            this.Controls.Add(this.tIPO_USUARIODataGridView);
            this.Controls.Add(this.tIPO_USUARIOBindingNavigator);
            this.Name = "Tipo_Usuario";
            this.Text = "Tipo_Usuario";
            this.Load += new System.EventHandler(this.Tipo_Usuario_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dERDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tIPO_USUARIOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tIPO_USUARIOBindingNavigator)).EndInit();
            this.tIPO_USUARIOBindingNavigator.ResumeLayout(false);
            this.tIPO_USUARIOBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tIPO_USUARIODataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DERDataSet dERDataSet;
        private System.Windows.Forms.BindingSource tIPO_USUARIOBindingSource;
        private EASYONE_SI.DERDataSetTableAdapters.TIPO_USUARIOTableAdapter tIPO_USUARIOTableAdapter;
        private EASYONE_SI.DERDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator tIPO_USUARIOBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton tIPO_USUARIOBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView tIPO_USUARIODataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.TextBox tipo_usuarioTextBox;
        private System.Windows.Forms.TextBox clasificaciónTextBox;
        private System.Windows.Forms.Button Agregar;
    }
}