﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EASYONE_SI
{
    public partial class Tipo_Usuario : Form
    {
        public Tipo_Usuario()
        {
            InitializeComponent();
        }

        private void tIPO_USUARIOBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tIPO_USUARIOBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dERDataSet);

        }

        private void Tipo_Usuario_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'dERDataSet.TIPO_USUARIO' Puede moverla o quitarla según sea necesario.
            this.tIPO_USUARIOTableAdapter.Fill(this.dERDataSet.TIPO_USUARIO);

        }
    }
}
