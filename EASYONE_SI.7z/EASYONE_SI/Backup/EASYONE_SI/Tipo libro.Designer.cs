﻿namespace EASYONE_SI
{
    partial class Tipo_libro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tipo_libro));
            System.Windows.Forms.Label id_tipolibroLabel;
            System.Windows.Forms.Label categoríaLabel;
            this.dERDataSet = new EASYONE_SI.DERDataSet();
            this.tIPO_lIBROBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tIPO_lIBROTableAdapter = new EASYONE_SI.DERDataSetTableAdapters.TIPO_lIBROTableAdapter();
            this.tableAdapterManager = new EASYONE_SI.DERDataSetTableAdapters.TableAdapterManager();
            this.tIPO_lIBROBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.tIPO_lIBROBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.tIPO_lIBRODataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.id_tipolibroTextBox = new System.Windows.Forms.TextBox();
            this.categoríaComboBox = new System.Windows.Forms.ComboBox();
            id_tipolibroLabel = new System.Windows.Forms.Label();
            categoríaLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dERDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tIPO_lIBROBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tIPO_lIBROBindingNavigator)).BeginInit();
            this.tIPO_lIBROBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tIPO_lIBRODataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // dERDataSet
            // 
            this.dERDataSet.DataSetName = "DERDataSet";
            this.dERDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tIPO_lIBROBindingSource
            // 
            this.tIPO_lIBROBindingSource.DataMember = "TIPO_lIBRO";
            this.tIPO_lIBROBindingSource.DataSource = this.dERDataSet;
            // 
            // tIPO_lIBROTableAdapter
            // 
            this.tIPO_lIBROTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.LIBROTableAdapter = null;
            this.tableAdapterManager.PRÉSTAMOTableAdapter = null;
            this.tableAdapterManager.TIPO_lIBROTableAdapter = this.tIPO_lIBROTableAdapter;
            this.tableAdapterManager.TIPO_USUARIOTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = EASYONE_SI.DERDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.USUARIOTableAdapter = null;
            // 
            // tIPO_lIBROBindingNavigator
            // 
            this.tIPO_lIBROBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.tIPO_lIBROBindingNavigator.BindingSource = this.tIPO_lIBROBindingSource;
            this.tIPO_lIBROBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.tIPO_lIBROBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.tIPO_lIBROBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.tIPO_lIBROBindingNavigatorSaveItem});
            this.tIPO_lIBROBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.tIPO_lIBROBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.tIPO_lIBROBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.tIPO_lIBROBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.tIPO_lIBROBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.tIPO_lIBROBindingNavigator.Name = "tIPO_lIBROBindingNavigator";
            this.tIPO_lIBROBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.tIPO_lIBROBindingNavigator.Size = new System.Drawing.Size(397, 25);
            this.tIPO_lIBROBindingNavigator.TabIndex = 0;
            this.tIPO_lIBROBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Mover primero";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Mover anterior";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Posición";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Posición actual";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 15);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Número total de elementos";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveNextItem.Text = "Mover siguiente";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveLastItem.Text = "Mover último";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Agregar nuevo";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorDeleteItem.Text = "Eliminar";
            // 
            // tIPO_lIBROBindingNavigatorSaveItem
            // 
            this.tIPO_lIBROBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tIPO_lIBROBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("tIPO_lIBROBindingNavigatorSaveItem.Image")));
            this.tIPO_lIBROBindingNavigatorSaveItem.Name = "tIPO_lIBROBindingNavigatorSaveItem";
            this.tIPO_lIBROBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 23);
            this.tIPO_lIBROBindingNavigatorSaveItem.Text = "Guardar datos";
            this.tIPO_lIBROBindingNavigatorSaveItem.Click += new System.EventHandler(this.tIPO_lIBROBindingNavigatorSaveItem_Click);
            // 
            // tIPO_lIBRODataGridView
            // 
            this.tIPO_lIBRODataGridView.AutoGenerateColumns = false;
            this.tIPO_lIBRODataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tIPO_lIBRODataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.tIPO_lIBRODataGridView.DataSource = this.tIPO_lIBROBindingSource;
            this.tIPO_lIBRODataGridView.Location = new System.Drawing.Point(50, 45);
            this.tIPO_lIBRODataGridView.Name = "tIPO_lIBRODataGridView";
            this.tIPO_lIBRODataGridView.Size = new System.Drawing.Size(243, 106);
            this.tIPO_lIBRODataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Id_tipolibro";
            this.dataGridViewTextBoxColumn1.HeaderText = "Id_tipolibro";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Categoría";
            this.dataGridViewTextBoxColumn2.HeaderText = "Categoría";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // id_tipolibroLabel
            // 
            id_tipolibroLabel.AutoSize = true;
            id_tipolibroLabel.Location = new System.Drawing.Point(63, 171);
            id_tipolibroLabel.Name = "id_tipolibroLabel";
            id_tipolibroLabel.Size = new System.Drawing.Size(58, 13);
            id_tipolibroLabel.TabIndex = 2;
            id_tipolibroLabel.Text = "Id tipolibro:";
            // 
            // id_tipolibroTextBox
            // 
            this.id_tipolibroTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tIPO_lIBROBindingSource, "Id_tipolibro", true));
            this.id_tipolibroTextBox.Location = new System.Drawing.Point(127, 168);
            this.id_tipolibroTextBox.Name = "id_tipolibroTextBox";
            this.id_tipolibroTextBox.Size = new System.Drawing.Size(100, 20);
            this.id_tipolibroTextBox.TabIndex = 3;
            // 
            // categoríaLabel
            // 
            categoríaLabel.AutoSize = true;
            categoríaLabel.Location = new System.Drawing.Point(63, 225);
            categoríaLabel.Name = "categoríaLabel";
            categoríaLabel.Size = new System.Drawing.Size(57, 13);
            categoríaLabel.TabIndex = 4;
            categoríaLabel.Text = "Categoría:";
            // 
            // categoríaComboBox
            // 
            this.categoríaComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tIPO_lIBROBindingSource, "Categoría", true));
            this.categoríaComboBox.FormattingEnabled = true;
            this.categoríaComboBox.Location = new System.Drawing.Point(126, 222);
            this.categoríaComboBox.Name = "categoríaComboBox";
            this.categoríaComboBox.Size = new System.Drawing.Size(121, 21);
            this.categoríaComboBox.TabIndex = 5;
            // 
            // Tipo_libro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(397, 320);
            this.Controls.Add(categoríaLabel);
            this.Controls.Add(this.categoríaComboBox);
            this.Controls.Add(id_tipolibroLabel);
            this.Controls.Add(this.id_tipolibroTextBox);
            this.Controls.Add(this.tIPO_lIBRODataGridView);
            this.Controls.Add(this.tIPO_lIBROBindingNavigator);
            this.Name = "Tipo_libro";
            this.Text = "Tipo_libro";
            this.Load += new System.EventHandler(this.Tipo_libro_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dERDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tIPO_lIBROBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tIPO_lIBROBindingNavigator)).EndInit();
            this.tIPO_lIBROBindingNavigator.ResumeLayout(false);
            this.tIPO_lIBROBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tIPO_lIBRODataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DERDataSet dERDataSet;
        private System.Windows.Forms.BindingSource tIPO_lIBROBindingSource;
        private EASYONE_SI.DERDataSetTableAdapters.TIPO_lIBROTableAdapter tIPO_lIBROTableAdapter;
        private EASYONE_SI.DERDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator tIPO_lIBROBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton tIPO_lIBROBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView tIPO_lIBRODataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.TextBox id_tipolibroTextBox;
        private System.Windows.Forms.ComboBox categoríaComboBox;
    }
}