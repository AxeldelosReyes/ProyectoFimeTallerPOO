﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EASYONE_SI
{
    public partial class Tipo_libro : Form
    {
        public Tipo_libro()
        {
            InitializeComponent();
        }

        private void tIPO_lIBROBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tIPO_lIBROBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dERDataSet);

        }

        private void Tipo_libro_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'dERDataSet.TIPO_lIBRO' Puede moverla o quitarla según sea necesario.
            this.tIPO_lIBROTableAdapter.Fill(this.dERDataSet.TIPO_lIBRO);

        }
    }
}
