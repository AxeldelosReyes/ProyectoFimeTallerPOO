﻿namespace EASYONE_SI
{
    partial class Usuarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Usuarios));
            System.Windows.Forms.Label id_UsuarioLabel;
            System.Windows.Forms.Label nombreLabel;
            System.Windows.Forms.Label ap_PaternoLabel;
            System.Windows.Forms.Label ap_MaternoLabel;
            System.Windows.Forms.Label tipo_UsuarioLabel;
            this.dERDataSet = new EASYONE_SI.DERDataSet();
            this.uSUARIOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.uSUARIOTableAdapter = new EASYONE_SI.DERDataSetTableAdapters.USUARIOTableAdapter();
            this.tableAdapterManager = new EASYONE_SI.DERDataSetTableAdapters.TableAdapterManager();
            this.uSUARIOBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.uSUARIOBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.id_UsuarioTextBox = new System.Windows.Forms.TextBox();
            this.nombreTextBox = new System.Windows.Forms.TextBox();
            this.ap_PaternoTextBox = new System.Windows.Forms.TextBox();
            this.ap_MaternoTextBox = new System.Windows.Forms.TextBox();
            this.tipo_UsuarioTextBox = new System.Windows.Forms.TextBox();
            this.uSUARIODataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button1 = new System.Windows.Forms.Button();
            id_UsuarioLabel = new System.Windows.Forms.Label();
            nombreLabel = new System.Windows.Forms.Label();
            ap_PaternoLabel = new System.Windows.Forms.Label();
            ap_MaternoLabel = new System.Windows.Forms.Label();
            tipo_UsuarioLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dERDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uSUARIOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uSUARIOBindingNavigator)).BeginInit();
            this.uSUARIOBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uSUARIODataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // dERDataSet
            // 
            this.dERDataSet.DataSetName = "DERDataSet";
            this.dERDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // uSUARIOBindingSource
            // 
            this.uSUARIOBindingSource.DataMember = "USUARIO";
            this.uSUARIOBindingSource.DataSource = this.dERDataSet;
            // 
            // uSUARIOTableAdapter
            // 
            this.uSUARIOTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.LIBROTableAdapter = null;
            this.tableAdapterManager.PRÉSTAMOTableAdapter = null;
            this.tableAdapterManager.TIPO_lIBROTableAdapter = null;
            this.tableAdapterManager.TIPO_USUARIOTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = EASYONE_SI.DERDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.USUARIOTableAdapter = this.uSUARIOTableAdapter;
            // 
            // uSUARIOBindingNavigator
            // 
            this.uSUARIOBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.uSUARIOBindingNavigator.BindingSource = this.uSUARIOBindingSource;
            this.uSUARIOBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.uSUARIOBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.uSUARIOBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.uSUARIOBindingNavigatorSaveItem});
            this.uSUARIOBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.uSUARIOBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.uSUARIOBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.uSUARIOBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.uSUARIOBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.uSUARIOBindingNavigator.Name = "uSUARIOBindingNavigator";
            this.uSUARIOBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.uSUARIOBindingNavigator.Size = new System.Drawing.Size(600, 25);
            this.uSUARIOBindingNavigator.TabIndex = 0;
            this.uSUARIOBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Mover primero";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Mover anterior";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Posición";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Posición actual";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 15);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Número total de elementos";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveNextItem.Text = "Mover siguiente";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveLastItem.Text = "Mover último";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Agregar nuevo";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorDeleteItem.Text = "Eliminar";
            // 
            // uSUARIOBindingNavigatorSaveItem
            // 
            this.uSUARIOBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.uSUARIOBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("uSUARIOBindingNavigatorSaveItem.Image")));
            this.uSUARIOBindingNavigatorSaveItem.Name = "uSUARIOBindingNavigatorSaveItem";
            this.uSUARIOBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 23);
            this.uSUARIOBindingNavigatorSaveItem.Text = "Guardar datos";
            this.uSUARIOBindingNavigatorSaveItem.Click += new System.EventHandler(this.uSUARIOBindingNavigatorSaveItem_Click);
            // 
            // id_UsuarioLabel
            // 
            id_UsuarioLabel.AutoSize = true;
            id_UsuarioLabel.Location = new System.Drawing.Point(25, 61);
            id_UsuarioLabel.Name = "id_UsuarioLabel";
            id_UsuarioLabel.Size = new System.Drawing.Size(58, 13);
            id_UsuarioLabel.TabIndex = 1;
            id_UsuarioLabel.Text = "Id Usuario:";
            // 
            // id_UsuarioTextBox
            // 
            this.id_UsuarioTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.uSUARIOBindingSource, "Id_Usuario", true));
            this.id_UsuarioTextBox.Location = new System.Drawing.Point(89, 58);
            this.id_UsuarioTextBox.Name = "id_UsuarioTextBox";
            this.id_UsuarioTextBox.Size = new System.Drawing.Size(100, 20);
            this.id_UsuarioTextBox.TabIndex = 2;
            // 
            // nombreLabel
            // 
            nombreLabel.AutoSize = true;
            nombreLabel.Location = new System.Drawing.Point(36, 104);
            nombreLabel.Name = "nombreLabel";
            nombreLabel.Size = new System.Drawing.Size(47, 13);
            nombreLabel.TabIndex = 3;
            nombreLabel.Text = "Nombre:";
            // 
            // nombreTextBox
            // 
            this.nombreTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.uSUARIOBindingSource, "Nombre", true));
            this.nombreTextBox.Location = new System.Drawing.Point(89, 104);
            this.nombreTextBox.Name = "nombreTextBox";
            this.nombreTextBox.Size = new System.Drawing.Size(100, 20);
            this.nombreTextBox.TabIndex = 4;
            // 
            // ap_PaternoLabel
            // 
            ap_PaternoLabel.AutoSize = true;
            ap_PaternoLabel.Location = new System.Drawing.Point(20, 144);
            ap_PaternoLabel.Name = "ap_PaternoLabel";
            ap_PaternoLabel.Size = new System.Drawing.Size(63, 13);
            ap_PaternoLabel.TabIndex = 5;
            ap_PaternoLabel.Text = "Ap Paterno:";
            // 
            // ap_PaternoTextBox
            // 
            this.ap_PaternoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.uSUARIOBindingSource, "Ap_Paterno", true));
            this.ap_PaternoTextBox.Location = new System.Drawing.Point(89, 141);
            this.ap_PaternoTextBox.Name = "ap_PaternoTextBox";
            this.ap_PaternoTextBox.Size = new System.Drawing.Size(100, 20);
            this.ap_PaternoTextBox.TabIndex = 6;
            // 
            // ap_MaternoLabel
            // 
            ap_MaternoLabel.AutoSize = true;
            ap_MaternoLabel.Location = new System.Drawing.Point(20, 174);
            ap_MaternoLabel.Name = "ap_MaternoLabel";
            ap_MaternoLabel.Size = new System.Drawing.Size(65, 13);
            ap_MaternoLabel.TabIndex = 7;
            ap_MaternoLabel.Text = "Ap Materno:";
            // 
            // ap_MaternoTextBox
            // 
            this.ap_MaternoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.uSUARIOBindingSource, "Ap_Materno", true));
            this.ap_MaternoTextBox.Location = new System.Drawing.Point(91, 174);
            this.ap_MaternoTextBox.Name = "ap_MaternoTextBox";
            this.ap_MaternoTextBox.Size = new System.Drawing.Size(100, 20);
            this.ap_MaternoTextBox.TabIndex = 8;
            // 
            // tipo_UsuarioLabel
            // 
            tipo_UsuarioLabel.AutoSize = true;
            tipo_UsuarioLabel.Location = new System.Drawing.Point(13, 206);
            tipo_UsuarioLabel.Name = "tipo_UsuarioLabel";
            tipo_UsuarioLabel.Size = new System.Drawing.Size(70, 13);
            tipo_UsuarioLabel.TabIndex = 9;
            tipo_UsuarioLabel.Text = "Tipo Usuario:";
            // 
            // tipo_UsuarioTextBox
            // 
            this.tipo_UsuarioTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.uSUARIOBindingSource, "Tipo_Usuario", true));
            this.tipo_UsuarioTextBox.Location = new System.Drawing.Point(91, 219);
            this.tipo_UsuarioTextBox.Name = "tipo_UsuarioTextBox";
            this.tipo_UsuarioTextBox.Size = new System.Drawing.Size(100, 20);
            this.tipo_UsuarioTextBox.TabIndex = 10;
            // 
            // uSUARIODataGridView
            // 
            this.uSUARIODataGridView.AutoGenerateColumns = false;
            this.uSUARIODataGridView.BackgroundColor = System.Drawing.Color.RosyBrown;
            this.uSUARIODataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.uSUARIODataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.uSUARIODataGridView.DataSource = this.uSUARIOBindingSource;
            this.uSUARIODataGridView.Location = new System.Drawing.Point(39, 265);
            this.uSUARIODataGridView.Name = "uSUARIODataGridView";
            this.uSUARIODataGridView.Size = new System.Drawing.Size(540, 167);
            this.uSUARIODataGridView.TabIndex = 11;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Id_Usuario";
            this.dataGridViewTextBoxColumn1.HeaderText = "Id_Usuario";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Nombre";
            this.dataGridViewTextBoxColumn2.HeaderText = "Nombre";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Ap_Paterno";
            this.dataGridViewTextBoxColumn3.HeaderText = "Ap_Paterno";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Ap_Materno";
            this.dataGridViewTextBoxColumn4.HeaderText = "Ap_Materno";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Tipo_Usuario";
            this.dataGridViewTextBoxColumn5.HeaderText = "Tipo_Usuario";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(247, 110);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(108, 51);
            this.button1.TabIndex = 12;
            this.button1.Text = "Agregar Usuario";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // Usuarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.ClientSize = new System.Drawing.Size(600, 460);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.uSUARIODataGridView);
            this.Controls.Add(tipo_UsuarioLabel);
            this.Controls.Add(this.tipo_UsuarioTextBox);
            this.Controls.Add(ap_MaternoLabel);
            this.Controls.Add(this.ap_MaternoTextBox);
            this.Controls.Add(ap_PaternoLabel);
            this.Controls.Add(this.ap_PaternoTextBox);
            this.Controls.Add(nombreLabel);
            this.Controls.Add(this.nombreTextBox);
            this.Controls.Add(id_UsuarioLabel);
            this.Controls.Add(this.id_UsuarioTextBox);
            this.Controls.Add(this.uSUARIOBindingNavigator);
            this.Name = "Usuarios";
            this.Text = "Usuarios";
            this.Load += new System.EventHandler(this.Usuarios_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dERDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uSUARIOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uSUARIOBindingNavigator)).EndInit();
            this.uSUARIOBindingNavigator.ResumeLayout(false);
            this.uSUARIOBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uSUARIODataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DERDataSet dERDataSet;
        private System.Windows.Forms.BindingSource uSUARIOBindingSource;
        private EASYONE_SI.DERDataSetTableAdapters.USUARIOTableAdapter uSUARIOTableAdapter;
        private EASYONE_SI.DERDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator uSUARIOBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton uSUARIOBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox id_UsuarioTextBox;
        private System.Windows.Forms.TextBox nombreTextBox;
        private System.Windows.Forms.TextBox ap_PaternoTextBox;
        private System.Windows.Forms.TextBox ap_MaternoTextBox;
        private System.Windows.Forms.TextBox tipo_UsuarioTextBox;
        private System.Windows.Forms.DataGridView uSUARIODataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.Button button1;
    }
}