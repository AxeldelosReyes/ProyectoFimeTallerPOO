﻿namespace EASYONE_SI
{
    partial class Agregar_libros1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.id_lib = new System.Windows.Forms.TextBox();
            this.nombrelib = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cantidad = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(101, 154);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(87, 26);
            this.button1.TabIndex = 0;
            this.button1.Text = "Agregar libro";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(69, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Id_Libro";
            // 
            // id_lib
            // 
            this.id_lib.Location = new System.Drawing.Point(124, 34);
            this.id_lib.Name = "id_lib";
            this.id_lib.Size = new System.Drawing.Size(100, 20);
            this.id_lib.TabIndex = 2;
            this.id_lib.TextChanged += new System.EventHandler(this.id_lib_TextChanged);
            // 
            // nombrelib
            // 
            this.nombrelib.Location = new System.Drawing.Point(124, 72);
            this.nombrelib.Name = "nombrelib";
            this.nombrelib.Size = new System.Drawing.Size(100, 20);
            this.nombrelib.TabIndex = 4;
            this.nombrelib.TextChanged += new System.EventHandler(this.nombrelib_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(52, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Nombre libro";
            // 
            // cantidad
            // 
            this.cantidad.Location = new System.Drawing.Point(124, 109);
            this.cantidad.Name = "cantidad";
            this.cantidad.Size = new System.Drawing.Size(100, 20);
            this.cantidad.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(69, 112);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Cantidad";
            // 
            // Agregar_libros1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::EASYONE_SI.Properties.Resources.fondo;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(267, 220);
            this.Controls.Add(this.cantidad);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.nombrelib);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.id_lib);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Name = "Agregar_libros1";
            this.Text = "Agregar Libros";
            this.Load += new System.EventHandler(this.Agregar_libros1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox id_lib;
        private System.Windows.Forms.TextBox nombrelib;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox cantidad;
        private System.Windows.Forms.Label label3;
    }
}