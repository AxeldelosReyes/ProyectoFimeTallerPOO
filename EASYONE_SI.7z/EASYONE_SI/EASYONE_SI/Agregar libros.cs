﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace EASYONE_SI
{
    public partial class Agregar_libros1 : Form
    {
        public Agregar_libros1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (id_lib.Text == "" || nombrelib.Text == "" || cantidad.Text == "")
            {
                MessageBox.Show("Favor de llenar todos los campos");
            }
            else
            {
                OleDbConnection conexion = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:/Base/base1.accdb");
                conexion.Open();
                string comprobacion = "SELECT Id_Libro FROM LIBRO WHERE Id_Libro =@Id_Libro";
                OleDbCommand comando = new OleDbCommand(comprobacion, conexion);
                comando.Parameters.AddWithValue("@Id_Libro", Convert.ToInt32(id_lib.Text));

                OleDbDataReader lector = comando.ExecuteReader();

                if (lector.Read())
                {
                    MessageBox.Show("Este libro ya fue registrado");
                }
                else
                {
                    int X = Convert.ToInt32(id_lib.Text);
                    Boolean errortotal = false;
                    try
                    {
                        string conect = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:/Base/base1.accdb";
                        OleDbConnection conexion1 = new OleDbConnection(conect);
                        conexion1.Open();

                        string insertar = "INSERT INTO LIBRO VALUES (@Id_Libro, @Nombre_Libro, @Cantidad)";
                        OleDbCommand cmd = new OleDbCommand(insertar, conexion);
                        cmd.Parameters.AddWithValue("@Id_Libro", Convert.ToInt32(id_lib.Text));
                        cmd.Parameters.AddWithValue("@Nombre_Libro", nombrelib.Text);
                        cmd.Parameters.AddWithValue("@Cantidad", Convert.ToInt32(cantidad.Text));

                        cmd.ExecuteNonQuery();

                        //cmd.Parameters.AddWithValue("@folio", Convert.ToInt32(txtfolio.Text));
                    }

                    catch (DBConcurrencyException ex)
                    {
                        errortotal = true;
                        MessageBox.Show("Error de concurrencia:\n" + ex.Message);
                    }
                    catch (Exception ex)
                    {
                        errortotal = true;
                        MessageBox.Show(ex.Message);
                    }
                    if (errortotal == false)
                    {
                        X += 1;
                        MessageBox.Show("Registro guardado");
                        id_lib.Text = "" + (X);
                        nombrelib.Text = "";
                        cantidad.Text = "";

                    }
                }
            }

        }

        private void Agregar_libros1_Load(object sender, EventArgs e)
        {
            OleDbConnection conexion = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:/Base/base1.accdb");
            conexion.Open();
            string auto_id = "SELECT Id_Libro FROM LIBRO";
            OleDbCommand comando_auto = new OleDbCommand(auto_id, conexion);
            OleDbDataReader lector_auto = comando_auto.ExecuteReader();
            int totalid = 1;
            while (lector_auto.Read())
            {
                totalid += 1;
                //String Id_auto = lector_auto["Id_prestamo"].ToString();
                //MessageBox.Show(""+Id_auto);
            }
            this.id_lib.Text = "" + totalid;

            lector_auto.Close();
            conexion.Close();
        }

        private void id_lib_TextChanged(object sender, EventArgs e)
        {

        }

        private void nombrelib_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
