﻿namespace EASYONE_SI
{
    partial class Agregar_trabajador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Agregar_trabajador));
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.nombrebox = new System.Windows.Forms.TextBox();
            this.contrabox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(216, 48);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Agregar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nombre:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Contraseña:";
            // 
            // nombrebox
            // 
            this.nombrebox.Location = new System.Drawing.Point(96, 33);
            this.nombrebox.Name = "nombrebox";
            this.nombrebox.Size = new System.Drawing.Size(100, 20);
            this.nombrebox.TabIndex = 3;
            this.nombrebox.TextChanged += new System.EventHandler(this.nombrebox_TextChanged);
            // 
            // contrabox
            // 
            this.contrabox.Location = new System.Drawing.Point(96, 69);
            this.contrabox.Name = "contrabox";
            this.contrabox.Size = new System.Drawing.Size(100, 20);
            this.contrabox.TabIndex = 4;
            // 
            // Agregar_trabajador
            // 
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(323, 119);
            this.Controls.Add(this.contrabox);
            this.Controls.Add(this.nombrebox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Name = "Agregar_trabajador";
            this.Text = "Agregar Trabajadores";
            this.Load += new System.EventHandler(this.Agregar_trabajador_Load_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox nombrebox;
        private System.Windows.Forms.TextBox contrabox;

        #endregion
        /*
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private DERDataSet1 dERDataSet1;
        private System.Windows.Forms.BindingSource administradorBindingSource;
        private DERDataSet1TableAdapters.administradorTableAdapter administradorTableAdapter;
        private DERDataSet1TableAdapters.TableAdapterManager tableAdapterManager;
         * */
    }
}