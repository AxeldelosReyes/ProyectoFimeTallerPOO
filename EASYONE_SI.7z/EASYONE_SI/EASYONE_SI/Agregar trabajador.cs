﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace EASYONE_SI
{
    public partial class Agregar_trabajador : Form
    {
        public Agregar_trabajador()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void administradorBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            //this.Validate();
            //this.administradorBindingSource.EndEdit();
            //this.tableAdapterManager.UpdateAll(this.dERDataSet1);

        }

        private void Agregar_trabajador_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'dERDataSet1.administrador' Puede moverla o quitarla según sea necesario.
            //this.administradorTableAdapter.Fill(this.dERDataSet1.administrador);

        }

        private void tRABAJADORBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            //this.Validate();
            //this.tRABAJADORBindingSource.EndEdit();
            //this.tableAdapterManager.UpdateAll(this.sistema_baseDataSet);

        }

        private void Agregar_trabajador_Load_1(object sender, EventArgs e)
        {
            
            // TODO: esta línea de código carga datos en la tabla 'sistema_baseDataSet.TRABAJADOR' Puede moverla o quitarla según sea necesario.
            //this.tRABAJADORTableAdapter.Fill(this.sistema_baseDataSet.TRABAJADOR);
            // TODO: esta línea de código carga datos en la tabla 'sistema_baseDataSet.ADMINISTRADOR' Puede moverla o quitarla según sea necesario.
            //this.aDMINISTRADORTableAdapter.Fill(this.sistema_baseDataSet.ADMINISTRADOR);
            // TODO: esta línea de código carga datos en la tabla 'sistema_baseDataSet.TRABAJADOR' Puede moverla o quitarla según sea necesario.
            //this.tRABAJADORTableAdapter.Fill(this.sistema_baseDataSet.TRABAJADOR);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Esta guarda en tabla trabajador

            //this.Validate();
            //this.tRABAJADORBindingSource.EndEdit();
            //this.tableAdapterManager.UpdateAll(this.sistema_baseDataSet);
        }

        private void tRABAJADORBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            //this.Validate();
            //this.tRABAJADORBindingSource.EndEdit();
            //this.tableAdapterManager.UpdateAll(this.sistema_baseDataSet);

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                string conect = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:/Base/base1.accdb";
                OleDbConnection conexion = new OleDbConnection(conect);
                conexion.Open();

                string insertar = "INSERT INTO TRABAJADOR VALUES (@Nombre , @Contraseña)";
                OleDbCommand cmd = new OleDbCommand(insertar, conexion);
                cmd.Parameters.AddWithValue("@Nombre", nombrebox.Text);
                cmd.Parameters.AddWithValue("@Contraseña", contrabox.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Registro guardado");

            }

            catch (DBConcurrencyException ex)
            {
                MessageBox.Show("Error de concurrencia:\n" + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }









        }

        private void nombrebox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
