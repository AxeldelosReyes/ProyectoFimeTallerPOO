﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EASYONE_SI
{
    public partial class BaseLib : Form
    {
        public BaseLib()
        {
            InitializeComponent();
        }

        private void tIPO_lIBROBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            //this.Validate();
            //this.tIPO_lIBROBindingSource.EndEdit();
            //this.tableAdapterManager.UpdateAll(this.dERDataSet);

        }

        private void Tipo_libro_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'dERDataSet.TIPO_lIBRO' Puede moverla o quitarla según sea necesario.
            //this.tIPO_lIBROTableAdapter.Fill(this.dERDataSet.TIPO_lIBRO);

        }

        private void tIPO_lIBROBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            //this.Validate();
            //this.tIPO_lIBROBindingSource.EndEdit();
            //this.tableAdapterManager.UpdateAll(this.sistema_baseDataSet);

        }

        private void Tipo_libro_Load_1(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'sistema_baseDataSet.TIPO_lIBRO' Puede moverla o quitarla según sea necesario.
            //this.tIPO_lIBROTableAdapter.Fill(this.sistema_baseDataSet.TIPO_lIBRO);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("file:///C:/Base/base1.accdb");
        }
    }
}
