﻿namespace EASYONE_SI
{
    partial class Buscar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Buscar));
            this.label1 = new System.Windows.Forms.Label();
            this.pRESTAMOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.baseDataSet1 = new EASYONE_SI.baseDataSet1();
            this.matricula = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.nomb = new System.Windows.Forms.TextBox();
            this.pat = new System.Windows.Forms.TextBox();
            this.mat = new System.Windows.Forms.TextBox();
            this.tip = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.lupa = new System.Windows.Forms.PictureBox();
            this.dav = new System.Windows.Forms.DataGridView();
            this.pRESTAMOTableAdapter = new EASYONE_SI.baseDataSet1TableAdapters.PRESTAMOTableAdapter();
            this.button3 = new System.Windows.Forms.Button();
            this.dataTable1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1 = new EASYONE_SI.DataSet1();
            this.dataTable1TableAdapter = new EASYONE_SI.DataSet1TableAdapters.DataTable1TableAdapter();
            this.button4 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pRESTAMOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.baseDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lupa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dav)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.pRESTAMOBindingSource, "Fecha_Prestamo", true));
            this.label1.Location = new System.Drawing.Point(12, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(155, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ingresa la matricula del usuario:";
            // 
            // pRESTAMOBindingSource
            // 
            this.pRESTAMOBindingSource.DataMember = "PRESTAMO";
            this.pRESTAMOBindingSource.DataSource = this.baseDataSet1;
            // 
            // baseDataSet1
            // 
            this.baseDataSet1.DataSetName = "baseDataSet1";
            this.baseDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // matricula
            // 
            this.matricula.Location = new System.Drawing.Point(176, 27);
            this.matricula.Name = "matricula";
            this.matricula.Size = new System.Drawing.Size(100, 20);
            this.matricula.TabIndex = 1;
            this.matricula.TextChanged += new System.EventHandler(this.matricula_TextChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(309, 110);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(118, 27);
            this.button1.TabIndex = 2;
            this.button1.Text = "Buscar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(114, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Nombre:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Location = new System.Drawing.Point(78, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Apellido Paterno:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Location = new System.Drawing.Point(78, 131);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Apellido Materno:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Location = new System.Drawing.Point(84, 157);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Tipo de usuario:";
            this.label6.Visible = false;
            // 
            // nomb
            // 
            this.nomb.Enabled = false;
            this.nomb.Location = new System.Drawing.Point(173, 76);
            this.nomb.Name = "nomb";
            this.nomb.Size = new System.Drawing.Size(100, 20);
            this.nomb.TabIndex = 8;
            // 
            // pat
            // 
            this.pat.Enabled = false;
            this.pat.Location = new System.Drawing.Point(173, 102);
            this.pat.Name = "pat";
            this.pat.Size = new System.Drawing.Size(100, 20);
            this.pat.TabIndex = 9;
            // 
            // mat
            // 
            this.mat.Enabled = false;
            this.mat.Location = new System.Drawing.Point(173, 128);
            this.mat.Name = "mat";
            this.mat.Size = new System.Drawing.Size(100, 20);
            this.mat.TabIndex = 10;
            // 
            // tip
            // 
            this.tip.Enabled = false;
            this.tip.Location = new System.Drawing.Point(173, 154);
            this.tip.Name = "tip";
            this.tip.Size = new System.Drawing.Size(100, 20);
            this.tip.TabIndex = 11;
            this.tip.Visible = false;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(309, 146);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(118, 28);
            this.button2.TabIndex = 12;
            this.button2.Text = "Nueva Busqueda";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // lupa
            // 
            this.lupa.BackColor = System.Drawing.Color.Transparent;
            this.lupa.Image = ((System.Drawing.Image)(resources.GetObject("lupa.Image")));
            this.lupa.Location = new System.Drawing.Point(329, 27);
            this.lupa.Name = "lupa";
            this.lupa.Size = new System.Drawing.Size(76, 65);
            this.lupa.TabIndex = 13;
            this.lupa.TabStop = false;
            this.lupa.Visible = false;
            // 
            // dav
            // 
            this.dav.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dav.Location = new System.Drawing.Point(12, 211);
            this.dav.Name = "dav";
            this.dav.Size = new System.Drawing.Size(264, 127);
            this.dav.TabIndex = 14;
            this.dav.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // pRESTAMOTableAdapter
            // 
            this.pRESTAMOTableAdapter.ClearBeforeFill = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(348, 222);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(118, 28);
            this.button3.TabIndex = 15;
            this.button3.Text = "Ver Prestamos";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // dataTable1BindingSource
            // 
            this.dataTable1BindingSource.DataMember = "DataTable1";
            this.dataTable1BindingSource.DataSource = this.dataSet1;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataTable1TableAdapter
            // 
            this.dataTable1TableAdapter.ClearBeforeFill = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(348, 281);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(118, 28);
            this.button4.TabIndex = 16;
            this.button4.Text = "Ver Devoluciones";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // Buscar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(491, 350);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.dav);
            this.Controls.Add(this.lupa);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.tip);
            this.Controls.Add(this.mat);
            this.Controls.Add(this.pat);
            this.Controls.Add(this.nomb);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.matricula);
            this.Controls.Add(this.label1);
            this.Name = "Buscar";
            this.Text = "Buscar";
            this.Load += new System.EventHandler(this.Buscar_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.pRESTAMOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.baseDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lupa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dav)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox matricula;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox nomb;
        private System.Windows.Forms.TextBox pat;
        private System.Windows.Forms.TextBox mat;
        private System.Windows.Forms.TextBox tip;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox lupa;
        private System.Windows.Forms.DataGridView dav;
        private baseDataSet1 baseDataSet1;
        private System.Windows.Forms.BindingSource pRESTAMOBindingSource;
        private baseDataSet1TableAdapters.PRESTAMOTableAdapter pRESTAMOTableAdapter;
        private DataSet1 dataSet1;
        private System.Windows.Forms.BindingSource dataTable1BindingSource;
        private DataSet1TableAdapters.DataTable1TableAdapter dataTable1TableAdapter;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
    }
}