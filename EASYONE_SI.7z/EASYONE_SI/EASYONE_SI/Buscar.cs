﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace EASYONE_SI
{
    public partial class Buscar : Form
    {
        public Buscar()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nombre, paterno, materno;
            OleDbConnection conexion = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:/Base/base1.accdb");
            conexion.Open();
            string consulta = "SELECT Id_Usuario, Nombre, Ap_Paterno, Ap_Materno FROM USUARIO where Id_Usuario="+ Convert.ToInt32(matricula.Text)+";";
            OleDbCommand Comando = new OleDbCommand(consulta, conexion);
            OleDbDataReader Datos = Comando.ExecuteReader();
            Boolean existe = Datos.HasRows;
            if (existe)
            {
                while (Datos.Read())
                {
                    nombre = Datos.GetString(Datos.GetOrdinal("Nombre"));
                    nomb.Text = nombre;
                    paterno = Datos.GetString(Datos.GetOrdinal("Ap_Paterno"));
                    pat.Text = paterno;
                    materno = Datos.GetString(Datos.GetOrdinal("Ap_Materno"));
                    mat.Text = materno;
                    //tipo = Datos.GetString(Datos.GetOrdinal("Tipo_Usuario"));

                    //if (tipo == "1")
                    //{
                    //    tip.Text = "Estudiante";
                    //}
                    //else if (tipo == "2")
                    //{
                    //    tip.Text = "Maestro";
                    //}
                }
            }
            else
            {
                MessageBox.Show("El usuario no existe en el sistema");
            }
            



        }

        private void button2_Click(object sender, EventArgs e)
        {
            matricula.Text = "";
            nomb.Text = "";
            pat.Text = "";
            mat.Text = "";
            tip.Text = "";
            lupa.Visible = false;
        }

        private void matricula_TextChanged(object sender, EventArgs e)
        {
            
                lupa.Visible = true;
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void Buscar_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'baseDataSet1.PRESTAMO' table. You can move, or remove it, as needed.
        }

        private void Buscar_Load_1(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet1.DataTable1' table. You can move, or remove it, as needed.
           // this.dataTable1TableAdapter.Fill(this.dataSet1.DataTable1);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (matricula.Text != "") {
                String sql = @"SELECT    LIBRO.Nombre_Libro, PRESTAMO.Fecha_Prestamo
                            FROM            ((USUARIO INNER JOIN
                         PRESTAMO ON USUARIO.Id_Usuario = PRESTAMO.id_Usuario) INNER JOIN
                         LIBRO ON PRESTAMO.Id_Libro = LIBRO.Id_Libro) WHERE PRESTAMO.id_Usuario  =" + Convert.ToInt32(matricula.Text) + ";";
                OleDbConnection conexion1 = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:/Base/base1.accdb");
                conexion1.Open();
                string consulta1 = "SELECT LIBRO.Nombre_Libro, PRESTAMO.Fecha_Prestamo, DEVOLUCION.Fecha_Devolucion FROM((DEVOLUCION INNER JOIN LIBRO ON DEVOLUCION.id_libro = LIBRO.Id_Libro) INNER JOIN PRESTAMO ON DEVOLUCION.id_Usuario = PRESTAMO.id_Usuario AND LIBRO.Id_Libro = PRESTAMO.Id_Libro) WHERE PRESTAMO.id_Usuario AND DEVOLUCION.id_Usuario  =" + Convert.ToInt32(matricula.Text) + ";";
                OleDbCommand Comando1 = new OleDbCommand(consulta1, conexion1);
                OleDbDataAdapter da = new OleDbDataAdapter(sql, conexion1);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dav.DataSource = dt;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (matricula.Text != "")
            {
                String sql2 = @"SELECT        LIBRO.Nombre_Libro, DEVOLUCION.Fecha_Devolucion 
FROM            ((LIBRO INNER JOIN
                         DEVOLUCION ON LIBRO.Id_Libro = DEVOLUCION.id_libro) INNER JOIN
                         USUARIO ON DEVOLUCION.id_Usuario = USUARIO.Id_Usuario) WHERE DEVOLUCION.id_Usuario  =" + Convert.ToInt32(matricula.Text) + ";";
                OleDbConnection conexion2 = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:/Base/base1.accdb");
                conexion2.Open();
                string consulta1 = "SELECT LIBRO.Nombre_Libro, PRESTAMO.Fecha_Prestamo, DEVOLUCION.Fecha_Devolucion FROM((DEVOLUCION INNER JOIN LIBRO ON DEVOLUCION.id_libro = LIBRO.Id_Libro) INNER JOIN PRESTAMO ON DEVOLUCION.id_Usuario = PRESTAMO.id_Usuario AND LIBRO.Id_Libro = PRESTAMO.Id_Libro) WHERE PRESTAMO.id_Usuario AND DEVOLUCION.id_Usuario  =" + Convert.ToInt32(matricula.Text) + ";";
                OleDbCommand Comando1 = new OleDbCommand(consulta1, conexion2);
                OleDbDataAdapter da2 = new OleDbDataAdapter(sql2, conexion2);
                DataTable dt2 = new DataTable();
                da2.Fill(dt2);

                dav.DataSource = dt2;
            }
        }
    }
}
