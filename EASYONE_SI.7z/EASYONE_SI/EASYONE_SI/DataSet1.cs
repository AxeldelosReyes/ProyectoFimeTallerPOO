﻿namespace EASYONE_SI
{


    partial class DataSet1
    {
    }
}


namespace EASYONE_SI.DataSet1TableAdapters {
    
    
    public partial class DataTable1TableAdapter {
    }
}
