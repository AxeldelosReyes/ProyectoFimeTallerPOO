﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace EASYONE_SI
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
             
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //Salto a abrir manulales
            System.Diagnostics.Process.Start("file:///C:/Base/Manual de usuario.docx");
        }

        private void idiomaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            

            int num;
       
                if (empleado.Text == "Administrador")
                {
                    OleDbConnection cadena = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Base\\base1.accdb");
                    cadena.Open();
                    string consulta = "Select administrador ,contrasena from ADMINISTRADOR where administrador= '" + nombreTextBox.Text + "'and contrasena ='" + contraseñaTextBox.Text + "';";
                    OleDbCommand comando = new OleDbCommand(consulta, cadena);
                    OleDbDataReader leer;
                    leer = comando.ExecuteReader();
                    Boolean existen = leer.HasRows;
                    if (existen)
                    {
                        num = 1;
                        MDI abrir = new MDI(num);
                        this.Hide();
                        abrir.Show();


                    }
                    else
                    {
                        MessageBox.Show("Datos no existentes");
                    }

                }
                else
                {
                    OleDbConnection cadena = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Base\\base1.accdb");
                    cadena.Open();
                    string consulta = "Select Nombre ,Contraseña from TRABAJADOR where Nombre= '" + nombreTextBox.Text + "'and Contraseña ='" + contraseñaTextBox.Text + "';";
                    OleDbCommand comando = new OleDbCommand(consulta, cadena);
                    OleDbDataReader leer;
                    leer = comando.ExecuteReader();
                    Boolean existen = leer.HasRows;
                    if (existen)
                    {
                        num = 0;
                        MDI abrir = new MDI(num);
                        this.Hide();
                        abrir.Show();


                    }
                    else
                    {
                        MessageBox.Show("Datos no existentes");
                    }
                }
            
            
            

        }

        private void cerrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void tRABAJADORBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tRABAJADORBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.sistema_baseDataSet);

        }

        private void Login_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'sistema_baseDataSet.TRABAJADOR' Puede moverla o quitarla según sea necesario.
            //this.tRABAJADORTableAdapter.Fill(this.sistema_baseDataSet.TRABAJADOR);
            nombreTextBox.Clear();
            contraseñaTextBox.Clear();

        }
    }
}
