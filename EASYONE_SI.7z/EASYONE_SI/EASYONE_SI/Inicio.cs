﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EASYONE_SI
{
    public partial class Inicio : Form
    {
        public Inicio()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        //private void button1_Click(object sender, EventArgs e)
        //{
            

            
        //}

        private void Inicio_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'sistema_baseDataSet.ADMINISTRADOR' Puede moverla o quitarla según sea necesario.
            // oc this.aDMINISTRADORTableAdapter.Fill(this.sistema_baseDataSet.ADMINISTRADOR);
            // TODO: esta línea de código carga datos en la tabla 'sistema_baseDataSet.ADMINISTRADOR' Puede moverla o quitarla según sea necesario.
            // oc this.aDMINISTRADORTableAdapter.Fill(this.sistema_baseDataSet.ADMINISTRADOR);
            // TODO: esta línea de código carga datos en la tabla 'sistema_baseDataSet.ADMINISTRADOR' Puede moverla o quitarla según sea necesario.
            //this.aDMINISTRADORTableAdapter.Fill(this.sistema_baseDataSet.ADMINISTRADOR);
            // TODO: esta línea de código carga datos en la tabla 'sistema_baseDataSet.ADMINISTRADOR' Puede moverla o quitarla según sea necesario.
            //this.aDMINISTRADORTableAdapter.Fill(this.sistema_baseDataSet.ADMINISTRADOR);
            // TODO: esta línea de código carga datos en la tabla 'sistema_baseDataSet.ADMINISTRADOR' Puede moverla o quitarla según sea necesario.
            //this.aDMINISTRADORTableAdapter.Fill(this.sistema_baseDataSet.ADMINISTRADOR);

        }

        //private void aDMINISTRADORBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        //{
        //    //this.Validate();
        //    //this.aDMINISTRADORBindingSource.EndEdit();
        //    //this.tableAdapterManager.UpdateAll(this.sistema_baseDataSet);

        //}

        //private void aDMINISTRADORBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        //{
        //    //this.Validate();
        //    //this.aDMINISTRADORBindingSource.EndEdit();
        //    //this.tableAdapterManager.UpdateAll(this.sistema_baseDataSet);

        //}

        private void administradorComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            


            string nombre, contra;
            nombre = adtext.Text;
            contra = cont.Text;
           
            Login abrir = new Login();
            this.Hide();
            abrir.Show();

            this.Validate();
            this.aDMINISTRADORBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.sistema_baseDataSet);
            

        }

        private void aDMINISTRADORBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.aDMINISTRADORBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.sistema_baseDataSet);

        }

        private void aDMINISTRADORBindingNavigator_RefreshItems(object sender, EventArgs e)
        {

        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {

        }

        private void aDMINISTRADORBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            this.Validate();
            this.aDMINISTRADORBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.sistema_baseDataSet);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Login abrir = new Login();
            abrir.Show();
        }

        private void bindingNavigatorAddNewItem_Click_1(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            MDI abrir1 = new MDI(1);
            
            abrir1.ShowDialog();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            System.Diagnostics.Process.Start("file:///F:/Datos/Datos xidos/Manual de usuario.docx");
        }
    }
}
