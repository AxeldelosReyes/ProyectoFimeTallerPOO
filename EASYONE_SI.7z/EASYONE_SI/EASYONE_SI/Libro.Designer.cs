﻿namespace EASYONE_SI
{
    partial class Libro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Libro));
            this.button1 = new System.Windows.Forms.Button();
            this.id_usuario = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.id_libro = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.fecha_d = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.id_dev = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(81, 188);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 23);
            this.button1.TabIndex = 17;
            this.button1.Text = "Generar devolucion";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // id_usuario
            // 
            this.id_usuario.Location = new System.Drawing.Point(131, 146);
            this.id_usuario.Name = "id_usuario";
            this.id_usuario.Size = new System.Drawing.Size(100, 20);
            this.id_usuario.TabIndex = 16;
            this.id_usuario.TextChanged += new System.EventHandler(this.id_usuario_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(70, 149);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "ID usuario";
            // 
            // id_libro
            // 
            this.id_libro.Location = new System.Drawing.Point(131, 105);
            this.id_libro.Name = "id_libro";
            this.id_libro.Size = new System.Drawing.Size(100, 20);
            this.id_libro.TabIndex = 14;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(78, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "ID_Libro";
            // 
            // fecha_d
            // 
            this.fecha_d.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.fecha_d.Location = new System.Drawing.Point(131, 63);
            this.fecha_d.Name = "fecha_d";
            this.fecha_d.Size = new System.Drawing.Size(100, 20);
            this.fecha_d.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Fecha de devolucion";
            // 
            // id_dev
            // 
            this.id_dev.Location = new System.Drawing.Point(131, 27);
            this.id_dev.Name = "id_dev";
            this.id_dev.Size = new System.Drawing.Size(100, 20);
            this.id_dev.TabIndex = 10;
            this.id_dev.TextChanged += new System.EventHandler(this.id_dev_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(49, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "ID_devolucion";
            // 
            // Libro
            // 
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(282, 237);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.id_usuario);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.id_libro);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.fecha_d);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.id_dev);
            this.Controls.Add(this.label1);
            this.Name = "Libro";
            this.Text = "Generar devolucion";
            this.Load += new System.EventHandler(this.Libro_Load_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox id_usuario;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox id_libro;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker fecha_d;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox id_dev;
        private System.Windows.Forms.Label label1;

        #endregion
        /*
        private DERDataSet dERDataSet;
        private System.Windows.Forms.BindingSource lIBROBindingSource;
        private EASYONE_SI.DERDataSetTableAdapters.LIBROTableAdapter lIBROTableAdapter;
        private EASYONE_SI.DERDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView lIBRODataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.TextBox id_LibroTextBox;
        private System.Windows.Forms.TextBox nombre_LibroTextBox;
        private System.Windows.Forms.TextBox cantidadTextBox;
        private System.Windows.Forms.CheckBox existenciaCheckBox;
        private System.Windows.Forms.ComboBox tipo_LibroComboBox;
        private System.Windows.Forms.Button button1;
        private EASYONE_SI.DERDataSetTableAdapters.USUARIOTableAdapter usuarioTableAdapter1;
         * */
    }
}