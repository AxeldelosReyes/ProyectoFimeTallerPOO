﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace EASYONE_SI
{
    public partial class Libro : Form
    {
        public Libro()
        {
            InitializeComponent();
        }

        private void lIBROBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            /*this.Validate();
            this.lIBROBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dERDataSet);
             * */

        }

        private void Libro_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'dERDataSet.LIBRO' Puede moverla o quitarla según sea necesario.
            //this.lIBROTableAdapter.Fill(this.dERDataSet.LIBRO);

        }

        private void lIBROBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            //this.Validate();
            //this.lIBROBindingSource.EndEdit();
            //this.tableAdapterManager.UpdateAll(this.sistema_baseDataSet);

        }

        private void Libro_Load_1(object sender, EventArgs e)
        {
            OleDbConnection conexion = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:/Base/base1.accdb");
            conexion.Open();
            string auto_id = "SELECT Id_devolucion FROM DEVOLUCION";
            OleDbCommand comando_auto = new OleDbCommand(auto_id, conexion);
            OleDbDataReader lector_auto = comando_auto.ExecuteReader();
            int totalid = 1;
            while (lector_auto.Read())
            {
                totalid += 1;
                //String Id_auto = lector_auto["Id_prestamo"].ToString();
                //MessageBox.Show(""+Id_auto);
            }
            this.id_dev.Text = "" + totalid;

            lector_auto.Close();
            conexion.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            
            //this.Validate();
            //this.lIBROBindingSource.EndEdit();
            //this.tableAdapterManager.UpdateAll(this.sistema_baseDataSet);

            

        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (id_usuario.Text == "" || id_libro.Text == "" || id_dev.Text == "")
            {
                MessageBox.Show("Favor de llenar todos los campos");
            }
            else
            {
                OleDbConnection conexion11 = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:/Base/base1.accdb");
                conexion11.Open();
                string comprobacion11 = "SELECT Id_Usuario FROM USUARIO WHERE Id_Usuario =@Id_Usuario";
                OleDbCommand comando11 = new OleDbCommand(comprobacion11, conexion11);
                comando11.Parameters.AddWithValue("@Id_Usuario", Convert.ToInt32(id_usuario.Text));

                OleDbDataReader lector11 = comando11.ExecuteReader();
                OleDbConnection conexion111 = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:/Base/base1.accdb");
                conexion111.Open();
                string comprobacion111 = "SELECT Id_Libro FROM LIBRO WHERE Id_Libro =@Id_Libro";
                OleDbCommand comando111 = new OleDbCommand(comprobacion111, conexion111);
                comando111.Parameters.AddWithValue("@Id_Libro", Convert.ToInt32(id_libro.Text));

                OleDbDataReader lector111 = comando111.ExecuteReader();

                if (!(lector111.Read()))
                {
                    MessageBox.Show("Este libro no existe");
                }
                else { 
                if (!(lector11.Read()))
                {
                    MessageBox.Show("El usuario no existe");
                }
                else
                {
                    OleDbConnection conexion = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:/Base/base1.accdb");
                conexion.Open();
                string comprobacion = "SELECT Id_devolucion FROM DEVOLUCION WHERE Id_devolucion =@Id_devolucion";
                OleDbCommand comando = new OleDbCommand(comprobacion, conexion);
                comando.Parameters.AddWithValue("@Id_Prestamo", Convert.ToInt32(id_dev.Text));
                OleDbDataReader lector = comando.ExecuteReader();
                //Nuevo
                string inv = "SELECT Cantidad FROM LIBRO WHERE Id_libro=@Id_libro";
                OleDbCommand comando_inv = new OleDbCommand(inv, conexion);
               
                comando_inv.Parameters.AddWithValue("@Id_Libro", Convert.ToInt32(id_libro.Text));
           
                OleDbDataReader lector_inv = comando_inv.ExecuteReader();

                String book_inv = "";
                while (lector_inv.Read())
                {
                    book_inv = lector_inv["Cantidad"].ToString();
                }
                //Fin
                Int32 Inventario = Convert.ToInt32(book_inv);
                        if (lector.Read())
                        {
                            MessageBox.Show("Esta devolucion ya fue registrada");
                        }
                        else
                        {
                            int X = Convert.ToInt32(id_dev.Text);
                            Boolean errortotal = false;

                            try
                            {
                                string conect = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:/Base/base1.accdb";
                                OleDbConnection conexion1 = new OleDbConnection(conect);
                                conexion1.Open();

                                string insertar = "INSERT INTO DEVOLUCION VALUES (@Id_devolucion, @Fecha_Devolucion, id_libro, @id_Usuario)";
                                OleDbCommand cmd = new OleDbCommand(insertar, conexion);
                                cmd.Parameters.AddWithValue("@Id_devolucion", Convert.ToInt32(id_dev.Text));
                                cmd.Parameters.AddWithValue("@Fecha_Devolucion", fecha_d.Value);
                                cmd.Parameters.AddWithValue("@id_libro", Convert.ToUInt32(id_libro.Text));
                                cmd.Parameters.AddWithValue("@id_Usuario", Convert.ToUInt32(id_usuario.Text));
                                cmd.ExecuteNonQuery();
                                //cmd.Parameters.AddWithValue("@folio", Convert.ToInt32(txtfolio.Text));
                            }

                            catch (DBConcurrencyException ex)
                            {
                                errortotal = true;
                                MessageBox.Show("Error de concurrencia:\n" + ex.Message);
                            }
                            catch (Exception ex)
                            {
                                errortotal = true;
                                MessageBox.Show(ex.Message);
                            }
                            if (Inventario == 0)
                            {
                                errortotal = true;
                                MessageBox.Show("No hay unidades disponibles del libro");
                            }
                            if (errortotal == false)
                            {
                                Inventario = Inventario + 1;
                                string conect = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:/Base/base1.accdb";
                                OleDbConnection conexion_stock = new OleDbConnection(conect);
                                conexion_stock.Open();
                                string insertar_stock = "update LIBRO set Cantidad='" + Inventario.ToString() + "' WHERE id_Libro=" + id_libro.Text;
                                OleDbCommand cmd_stock = new OleDbCommand(insertar_stock, conexion_stock);
                                cmd_stock.ExecuteNonQuery();
                                X += 1;
                                MessageBox.Show("Registro guardado");
                                id_dev.Text = "" + (X);
                                id_libro.Text = "";
                                id_usuario.Text = "";

                            }
                        }
                    }




                }
            }



        }

        private void id_dev_TextChanged(object sender, EventArgs e)
        {

        }

        private void id_usuario_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
