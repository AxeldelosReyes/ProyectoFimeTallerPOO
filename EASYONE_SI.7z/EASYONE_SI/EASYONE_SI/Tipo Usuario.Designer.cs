﻿namespace EASYONE_SI
{
    partial class Tipo_Usuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tipo_Usuario));
            this.sistema_baseDataSet = new EASYONE_SI.Sistema_baseDataSet();
            this.tIPO_USUARIOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tIPO_USUARIOTableAdapter = new EASYONE_SI.Sistema_baseDataSetTableAdapters.TIPO_USUARIOTableAdapter();
            this.tableAdapterManager = new EASYONE_SI.Sistema_baseDataSetTableAdapters.TableAdapterManager();
            this.tIPO_USUARIODataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.sistema_baseDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tIPO_USUARIOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tIPO_USUARIODataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // sistema_baseDataSet
            // 
            this.sistema_baseDataSet.DataSetName = "Sistema_baseDataSet";
            this.sistema_baseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tIPO_USUARIOBindingSource
            // 
            this.tIPO_USUARIOBindingSource.DataMember = "TIPO_USUARIO";
            this.tIPO_USUARIOBindingSource.DataSource = this.sistema_baseDataSet;
            // 
            // tIPO_USUARIOTableAdapter
            // 
            this.tIPO_USUARIOTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.ADMINISTRADORTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.LIBROTableAdapter = null;
            this.tableAdapterManager.PRESTAMOTableAdapter = null;
            this.tableAdapterManager.TIPO_lIBROTableAdapter = null;
            this.tableAdapterManager.TIPO_USUARIOTableAdapter = this.tIPO_USUARIOTableAdapter;
            this.tableAdapterManager.TRABAJADORTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = EASYONE_SI.Sistema_baseDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.USUARIOTableAdapter = null;
            // 
            // tIPO_USUARIODataGridView
            // 
            this.tIPO_USUARIODataGridView.AutoGenerateColumns = false;
            this.tIPO_USUARIODataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tIPO_USUARIODataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.tIPO_USUARIODataGridView.DataSource = this.tIPO_USUARIOBindingSource;
            this.tIPO_USUARIODataGridView.Location = new System.Drawing.Point(34, 26);
            this.tIPO_USUARIODataGridView.Name = "tIPO_USUARIODataGridView";
            this.tIPO_USUARIODataGridView.Size = new System.Drawing.Size(244, 96);
            this.tIPO_USUARIODataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Tipo_usuario";
            this.dataGridViewTextBoxColumn1.HeaderText = "Tipo_usuario";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Clasificación";
            this.dataGridViewTextBoxColumn2.HeaderText = "Clasificación";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // Tipo_Usuario
            // 
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(311, 152);
            this.Controls.Add(this.tIPO_USUARIODataGridView);
            this.Name = "Tipo_Usuario";
            this.Load += new System.EventHandler(this.Tipo_Usuario_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.sistema_baseDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tIPO_USUARIOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tIPO_USUARIODataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Sistema_baseDataSet sistema_baseDataSet;
        private System.Windows.Forms.BindingSource tIPO_USUARIOBindingSource;
        private EASYONE_SI.Sistema_baseDataSetTableAdapters.TIPO_USUARIOTableAdapter tIPO_USUARIOTableAdapter;
        private EASYONE_SI.Sistema_baseDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView tIPO_USUARIODataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        /*
        private DERDataSet dERDataSet;
        private System.Windows.Forms.BindingSource tIPO_USUARIOBindingSource;
        private EASYONE_SI.DERDataSetTableAdapters.TIPO_USUARIOTableAdapter tIPO_USUARIOTableAdapter;
        private EASYONE_SI.DERDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView tIPO_USUARIODataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.TextBox tipo_usuarioTextBox;
        private System.Windows.Forms.TextBox clasificaciónTextBox;
        private System.Windows.Forms.Button Agregar;
         * */
    }
}