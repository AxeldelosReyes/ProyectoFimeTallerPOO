﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace EASYONE_SI
{
    public partial class Usuarios : Form
    {

        OleDbConnection Conexion = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:/Users/Jose Arnaldo/Desktop/Ultimo sistema - copia/Sistema/EASYONE_SI/EASYONE_SI/base.accdb");
        OleDbCommand cmd = new OleDbCommand();
        public Usuarios()
        {
            InitializeComponent();
        }

        private void uSUARIOBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            //this.Validate();
            //this.uSUARIOBindingSource.EndEdit();
            //this.tableAdapterManager.UpdateAll(this.dERDataSet);

        }

        private void Usuarios_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'dERDataSet.USUARIO' Puede moverla o quitarla según sea necesario.
            //this.uSUARIOTableAdapter.Fill(this.dERDataSet.USUARIO);

        }

        private void uSUARIOBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            //this.Validate();
            //this.uSUARIOBindingSource.EndEdit();
            //this.tableAdapterManager.UpdateAll(this.sistema_baseDataSet);

        }

        private void Usuarios_Load_1(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'sistema_baseDataSet.USUARIO' Puede moverla o quitarla según sea necesario.
            //this.uSUARIOTableAdapter.Fill(this.sistema_baseDataSet.USUARIO);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //this.Validate();
            //this.uSUARIOBindingSource.EndEdit();
            //this.tableAdapterManager.UpdateAll(this.sistema_baseDataSet);

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (id_usuario.Text == "" || nombre.Text == "" || ap_paterno.Text == "" || ap_paterno.Text == "")
            {
                MessageBox.Show("Favor de llenar todos los campos");
            }
            else
            {
                OleDbConnection conexion = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:/Base/base1.accdb");
                conexion.Open();
                string comprobacion = "SELECT Id_Usuario FROM USUARIO WHERE Id_Usuario =@Id_Usuario";
                OleDbCommand comando = new OleDbCommand(comprobacion, conexion);
                comando.Parameters.AddWithValue("@Id_Usuario", Convert.ToInt32(id_usuario.Text));

                OleDbDataReader lector = comando.ExecuteReader();

                if (lector.Read())
                {
                    MessageBox.Show("El usuario ya existe");
                }
                else
                {
                    try
                    {
                        string conect = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:/Base/base1.accdb";
                        OleDbConnection conexion1 = new OleDbConnection(conect);
                        conexion1.Open();

                        string insertar = "INSERT INTO USUARIO VALUES (@Id_Usuario, @Nombre, @Ap_Paterno, @Ap_Materno)";
                        OleDbCommand cmd = new OleDbCommand(insertar, conexion);
                        cmd.Parameters.AddWithValue("@Id_Usuario", Convert.ToInt32(id_usuario.Text));
                        cmd.Parameters.AddWithValue("@Nombre", nombre.Text);
                        cmd.Parameters.AddWithValue("@Ap_Paterno", ap_paterno.Text);
                        cmd.Parameters.AddWithValue("@Ap_Materno", ap_materno.Text);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Registro guardado");
                        //cmd.Parameters.AddWithValue("@folio", Convert.ToInt32(txtfolio.Text));
                    }

                    catch (DBConcurrencyException ex)
                    {
                        MessageBox.Show("Error de concurrencia:\n" + ex.Message);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }




            }






        }

        private void id_usuario_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
