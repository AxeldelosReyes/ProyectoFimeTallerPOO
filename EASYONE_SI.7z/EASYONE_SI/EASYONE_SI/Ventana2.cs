﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace EASYONE_SI
{
    public partial class MDI : Form
    {
        int num;
        public MDI(int num2)
        {
            InitializeComponent();
            num = num2;
        }

        private void agregarToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void cerrarToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.ExitThread();
        }

        private void nuevoUsuarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //salto a nuevo usuario
            Usuarios nuevo = new Usuarios();
            nuevo.MdiParent = this;
            nuevo.Show();
        }

        private void prestamoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //salto a nuevo prestamo
            prestamo nuevo = new prestamo();
            nuevo.MdiParent = this;
            nuevo.Show();


        }

        private void nuevoLibroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //salto a nuevo libro
            Libro nuevo = new Libro();
            nuevo.MdiParent = this;
            nuevo.Show();
        }

        private void informeToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //generar informe
            Informee nuevo = new Informee();
            nuevo.MdiParent = this;
            nuevo.Show();
        }

        private void prestamoDeLibrosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //salto a prestamo de Libros
            prestamo nuevo = new prestamo();
            nuevo.MdiParent = this;
            nuevo.Show();
            

        }

        private void usuariosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //salñto a usuarios
            Usuarios abrir = new Usuarios();
            abrir.MdiParent = this;
            abrir.Show();

        }

        private void librosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //salto a libros
            BaseLib abrir = new BaseLib();
            abrir.MdiParent = this;
            abrir.Show();

        }

        private void informeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //salto a guardar tabla en .doc
            
        }

        private void buscarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Salto a abrir manulales
            System.Diagnostics.Process.Start("file:///C:/Base/Manual de usuario.docx");
             
        }

        private void soporteTécnicoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //salto a soporte
            System.Diagnostics.Process.Start("www.easypackcompany.com/easyone/soporte-tec");
        }

        private void sesiónToolStripMenuItem1_Click(object sender, EventArgs e)
        {
             Login nuevo = new Login();
             nuevo.Show();
             this.Hide();
            
           

        }

        private void easyOneToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void tiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BaseLib abrir = new BaseLib();
            abrir.MdiParent = this;
            abrir.Show();
            

        }

        private void baseDeDatosToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void nuevoTrabajadorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Agregar_trabajador abrir = new Agregar_trabajador();
            abrir.MdiParent = this;
            abrir.Show();

        }

        private void archivoToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            
        }

        private void archivoToolStripMenuItem_MouseMove(object sender, MouseEventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (progressBar1.Value == 500)
            {
                timer1.Enabled = false;
            }
            else
            {
                progressBar1.Value = progressBar1.Value + 50;
                
                this.Size = new Size(progressBar1.Value + 50, progressBar1.Value + 25);
                //string ruta = @"F:\Datos\Datos xidos\Iconos para el sistema\Fondo.jpg", prro=@"F:\Datos\Datos xidos\Iconos para el sistema\perro.png";
                //BackgroundImage = Image.FromFile(ruta);
                //BackgroundImageLayout = ImageLayout.Stretch;
                //pictureBox1.Image = Image.FromFile(prro);

            }
        }

        private void alumnosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Buscar nuevo = new Buscar();
            nuevo.MdiParent = this;
            nuevo.Show();
        }
        private void MDI_Load(object sender, EventArgs e)
        {
            
            timer1.Enabled = true;
            //int largo = 0, alto = 0, i, i2;
            //for (i = 136; i <= 684; i++)
            //{

            //  this.Size = new Size(largo++,0);
            //}
            //for (i2 = 63; i2 <= 487; i2++)
            //{
            //  alto++;
            //this.Size = new Size(0, alto);
            //}
            

            if (num == 1)
            {
                administrarToolStripMenuItem.Visible = true;
            }
            else
            {
                administrarToolStripMenuItem.Visible = false;
            }





        }

        private void prestamoAUsuariosToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void informeToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            Form3 abrir2 = new Form3();
            abrir2.MdiParent = this;
            this.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 abrir2 = new Form2();
            abrir2.MdiParent = this;
            this.Show();
        }

        private void saltoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 abrir2 = new Form2();
            abrir2.MdiParent = this;
            this.Show();
        }

        private void agregarLibrosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Agregar_libros1 abrir = new Agregar_libros1();
            abrir.MdiParent = this;
            abrir.Show();
        }
    }
}
